---
name: param-table-workflow
description: |
  This skill should be used when the user wants to adjust visual effect parameters,
  particle system settings, animation timing, 3D scene parameters, or any tunable
  numeric values in code. It ensures clear parameter communication via tables
  and zero-runtime-overhead organization in code.
agent_created: true
---

# 参数表沟通流程（Parameter Table Workflow）

## 目的
当用户要求调整特效、动画、粒子、3D 场景等可视化参数时，本 skill 规范沟通方式，
确保用户即使看不懂代码，也能直观地理解每个参数的作用、当前值和可调范围，
并直接说出"把这个改成X"。

## 触发条件
- 用户说"调一下粒子密度/大小/颜色"
- 用户说"鼠标影响范围太大了/太小了"
- 用户说"闪烁太明显/太慢"
- 用户给出一组参数值（如"ASH_COUNT=4000, influenceRadius=5.0"）
- 任何涉及调参的对话

## 执行流程

### Step 1: 提取参数（如果是第一次调参）
在代码文件中找到所有硬编码的可调数值，提取到文件顶部作为 `const` 命名常量。

规则：
- 只在代码最顶部（相关模块开头）声明，不要分散在各处
- 使用 `const` 声明原始值（number、string、boolean），V8 引擎会自动内联，**零运行时开销**
- 常量名用大写 + 下划线，如 `ASH_COUNT`、`MOUSE_INFLUENCE_RADIUS`
- 每个常量旁用注释注明：中文名、建议范围
- 如果某参数在 shader 中硬编码（如 GLSL 里的 `4.0`），在常量注释中注明"修改后需同步替换 shader 中对应值"

示例：
```javascript
// ========== 可调参数表（修改此处即可，无需翻找代码）==========
const ASH_COUNT = 4000;              // [粒子数量] 建议 2000~6000
const MOUSE_INFLUENCE_RADIUS = 5.0;  // [鼠标影响半径] 世界单位；建议 3~10
const MOUSE_MAX_FORCE = 150.0;        // [排斥力最大值] 建议 80~300
const MOUSE_SWIRL_STRENGTH = 50.0;   // [涡旋力强度] 建议 20~150
const SHADER_GLOW_RADIUS = 4.0;      // [Shader高亮半径] 建议 2~8（修改后需同步替换 shader 中两处硬编码）
const SIZE_FAR = [0.03, 0.08];       // [粒子大小-远景] 建议 [0.02, 0.15]
const SIZE_MID = [0.06, 0.18];       // [粒子大小-中景] 建议 [0.05, 0.30]
const SIZE_NEAR = [0.12, 0.18];      // [粒子大小-近景] 建议 [0.10, 0.40]
const Z_RANGE = [-15, 3];             // [Z分布范围] 建议 [-18, 5]~[-10, 8]
// ================================================================
```

### Step 2: 修改前展示参数表
在用户确认修改前，用**Markdown 表格**列出所有相关参数：

| 参数 | 当前值 | 建议范围 | 说明 |
|------|--------|----------|------|
| `ASH_COUNT` | 4000 | 2000~6000 | 粒子数量，越多越密集 |
| `MOUSE_INFLUENCE_RADIUS` | 5.0 | 3~10 | 鼠标影响半径（世界单位） |
| `MOUSE_MAX_FORCE` | 150.0 | 80~300 | 排斥力最大值 |

表格要求：
- 列：参数名（代码风格）、当前值、建议范围、中文说明
- 如果用户给出了目标值，加一列"目标值"
- 中文说明要简洁，一句话
- 如果是 shader 中的参数，在参数名后标注 `(shader)`

### Step 3: 应用修改并展示对比
修改代码后，再发一张对比表：

| 参数 | 改前 | 改后 | 说明 |
|------|------|------|------|
| `ASH_COUNT` | 1400 | **4000** | 密度提升，粒子更密集 |
| `MOUSE_INFLUENCE_RADIUS` | 10.0 | **5.0** | 影响范围减半 |

### Step 4: 如果用户直接给参数值
如果用户说"ASH_COUNT 改成 4000，influenceRadius 改成 5.0"：
1. 先展示确认表（当前值 → 目标值）
2. 确认后直接修改
3. 改完再发最终状态表

## 性能说明
`const` 声明的原始值在 V8 引擎编译时会被自动内联，与直接写数字字面量生成的机器码完全相同，
**零额外运行时开销**。数组访问如 `SIZE_FAR[0]` 也是常数时间，可忽略。
所以请放心在代码顶部使用命名常量，不会降低性能。

## 注意事项
- 不要过度设计：如果只有 1~2 个参数要调，不必大动干戈建参数表，直接改即可
- 只对**用户明确需要反复调整**的参数建表
- Shader 中的硬编码值（GLSL 字符串里的数字）需要在注释中提醒手动同步
- 如果参数之间有关联（如"范围缩小就要增加力度"），在说明中注明