---
name: cloudbase-web-db-setup
description: This skill should be used when a static web app using Tencent CloudBase encounters database errors like "Db or Table not exist" or needs to set up CloudBase database collections, security rules, and CDN cache busting for web projects.
agent_created: true
---

# CloudBase Web 数据库初始化技能

## 触发场景

当满足以下任一条件时使用本技能：

- 静态网站接入 CloudBase 数据库后报错 `Db or Table not exist: xxx`
- 需要为新项目创建 CloudBase 数据库集合
- 需要配置 CloudBase 数据库安全规则
- 部署 JS 文件后浏览器仍加载旧版本（CDN 缓存问题）

## 前置条件

- 已有 CloudBase 环境 ID（env）
- 网站已接入 CloudBase JS SDK 并完成登录初始化
- 已通过 `cloudbase.init()` 初始化 app

## 完整操作步骤

### 步骤 1：创建数据库集合

1. 打开 [CloudBase 控制台](https://tcb.cloud.tencent.com/dev)
2. 进入目标环境
3. 左侧菜单选择「数据库」
4. 点击「新建集合」，依次创建：

| 集合名 | 用途 |
|--------|------|
| `users` | 用户资料（昵称、头像、简介） |
| `characters` | 角色卡数据 |
| `sessions` | 游戏/跑团记录 |

> CloudBase 不会自动创建集合，必须在控制台手动创建或使用 CLI 创建。

### 步骤 2：配置数据库安全规则

1. 进入数据库 → 安全规则 / 权限设置
2. 将默认规则改为允许认证用户读写：

```json
{
  "read": "auth != null",
  "write": "auth != null"
}
```

如需限制用户只能读写自己的数据：

```json
{
  "read": "doc.uid == auth.uid",
  "write": "doc.uid == auth.uid"
}
```

### 步骤 3：代码中添加友好错误提示

在数据库操作模块中添加错误包装函数，识别常见错误：

```javascript
function friendlyError(err) {
  var msg = (err && (err.message || err.msg || err.errMsg || err.code)) || String(err);
  if (/Db or Table not exist|not exist|collection not found/i.test(msg)) {
    throw new Error('数据库集合未创建。请在 CloudBase 控制台建立 users、characters、sessions 三个集合。');
  }
  if (/permission denied|not authorized|auth/i.test(msg)) {
    throw new Error('数据库权限不足。请检查 CloudBase 数据库安全规则是否允许登录用户读写。');
  }
  throw new Error('云端保存失败：' + msg);
}
```

在每个数据库 Promise 链末尾添加 `.catch(friendlyError)`。

### 步骤 4：CDN 缓存破坏

更新 JS 文件引用时添加版本号，强制浏览器和 CDN 重新拉取：

```html
<script src="js/ash-db.js?v=2"></script>
<script src="js/ash-init.js?v=2"></script>
```

每次重大更新递增版本号。重新部署到 CloudBase 静态托管后，提示用户用无痕模式或 Ctrl+F5 强制刷新。

## 验证清单

- [ ] 三个集合 `users`、`characters`、`sessions` 已在控制台可见
- [ ] 安全规则允许 `auth != null` 或按 `uid` 隔离
- [ ] 代码中所有数据库操作都有 `.catch(friendlyError)`
- [ ] JS 引用带版本号 `?v=2`
- [ ] 部署后用无痕模式测试保存/读取流程

## 常见错误

| 错误 | 原因 | 解决 |
|------|------|------|
| `Db or Table not exist` | 集合未创建 | 控制台手动创建 |
| `permission denied` | 安全规则过严 | 改为 `auth != null` 或按 uid 授权 |
| 旧错误提示仍出现 | CDN 缓存 | 加版本号 `?v=2`，用无痕模式刷新 |
| 登录状态丢失 | 未设置持久化 | 初始化 auth 时加 `persistence: 'local'` |
