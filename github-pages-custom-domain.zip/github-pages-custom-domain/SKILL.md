---
name: github-pages-custom-domain
description: Set up a custom apex domain (e.g. example.com) for a GitHub Pages site using Tencent Cloud DNS. Covers DNS record limits, free-tier constraints, and HTTPS enablement. Use when a user wants to bind a purchased domain to a GitHub Pages repository.
agent_created: true
---

# GitHub Pages Custom Domain Setup

## When to Use

- A GitHub Pages site needs to be served from a custom domain instead of `username.github.io`.
- The domain is registered on Tencent Cloud and DNS is managed in Tencent Cloud DNS (云解析 DNS).
- The user wants to know the free-tier limits and costs before committing.

## Important Constraints

| Platform | Free Tier Limit | Cost to Upgrade |
|----------|-----------------|-----------------|
| GitHub Pages | Custom domain + HTTPS included | Free |
| Tencent Cloud DNS Free | 1 A record per subdomain (e.g. `@`) | ¥99/year for load balancing / multiple A records |

GitHub Pages officially recommends 4 A records for redundancy, but **1 A record is sufficient for functionality**. Adding more than 1 A record for `@` on Tencent Cloud DNS Free triggers the paid upgrade prompt.

## Required DNS Records

| Host Record | Type | Value |
|-------------|------|-------|
| `@` | A | `185.199.111.153` (any of the 4 GitHub Pages IPs) |
| `www` | CNAME | `<username>.github.io` |

GitHub Pages IPs (pick one for free tier):
- `185.199.108.153`
- `185.199.109.153`
- `185.199.110.153`
- `185.199.111.153`

## Workflow

1. **Get the GitHub Pages URL**
   - Confirm the repository is published on GitHub Pages.
   - Note the default URL: `https://<username>.github.io/<repo>/` or `https://<username>.github.io`.

2. **Configure DNS in Tencent Cloud Console**
   - Go to 云解析 DNS.
   - Select the target domain.
   - Add one A record for `@` pointing to a single GitHub Pages IP.
   - Add one CNAME record for `www` pointing to `<username>.github.io`.
   - Save and wait 2-5 minutes for propagation.

3. **Configure Domain in GitHub Pages**
   - Open the repository → Settings → Pages.
   - Under "Custom domain", enter the apex domain (e.g. `example.com`).
   - Save.
   - Wait for "DNS check successful" to appear.

4. **Enable HTTPS**
   - Once DNS check passes, the "Enforce HTTPS" checkbox will become available.
   - Check it and wait 1-5 minutes for certificate issuance.
   - Verify by visiting `https://example.com`.

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| DNS check failed | No A record or CNAME for the domain | Add/verify DNS records in Tencent Cloud DNS |
| Tencent prompts upgrade to paid DNS | More than 1 A record for `@` | Delete extra A records; keep only 1 |
| HTTPS unavailable after DNS check | Certificate still being issued | Wait 5-10 minutes and refresh |
| Site shows certificate warning | HTTPS certificate not ready | Wait longer or uncheck/recheck Enforce HTTPS |

## Verification Commands

```bash
# Check apex domain
nslookup example.com

# Check www subdomain
nslookup www.example.com
```
